package com.example.billiardtimer;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.content.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout list;
    final String[] names={"پاکت ۱","پاکت ۲","پاکت ۳","پاکت ۴","پاکت ۵","اسنوکر ۱","اسنوکر ۲"};
    final int[] rates={280000,280000,280000,280000,280000,380000,380000};
    long[] start=new long[7]; boolean[] running=new boolean[7]; Handler h=new Handler();
    ArrayList<TextView> info=new ArrayList<>(), buttons=new ArrayList<>();

    public void onCreate(Bundle b){super.onCreate(b); build(); h.post(tick);}
    TextView tv(String s,int sp){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setPadding(16,12,16,12); return t;}
    void build(){
      ScrollView sv=new ScrollView(this); list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(16,18,16,18);
      TextView title=tv("🎱 تایمر باشگاه",26); title.setTextColor(Color.BLACK); title.setGravity(Gravity.CENTER);
      list.addView(title);
      TextView sub=tv("پاکت: ساعتی ۲۸۰٬۰۰۰ تومان  |  اسنوکر: ساعتی ۳۸۰٬۰۰۰ تومان",15); sub.setGravity(Gravity.CENTER); list.addView(sub);
      for(int i=0;i<7;i++) addTable(i);
      sv.addView(list); setContentView(sv);
    }
    void addTable(final int i){
      LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(8,12,8,12);
      TextView n=tv(names[i]+"   •   "+fmt(rates[i])+" تومان/ساعت",20);
      TextView inf=tv("آزاد",18); info.add(inf);
      Button btn=new Button(this); btn.setText("شروع"); buttons.add(btn);
      btn.setOnClickListener(v->{ if(!running[i]){start[i]=System.currentTimeMillis(); running[i]=true; btn.setText("توقف");}
        else {running[i]=false; btn.setText("شروع"); update(i);}
      });
      Button reset=new Button(this); reset.setText("صفر کردن");
      reset.setOnClickListener(v->{running[i]=false; start[i]=0; btn.setText("شروع"); inf.setText("آزاد");});
      card.addView(n); card.addView(inf); card.addView(btn); card.addView(reset);
      list.addView(card);
    }
    void update(int i){
      if(!running[i] && start[i]==0){info.get(i).setText("آزاد");return;}
      long sec=(System.currentTimeMillis()-start[i])/1000;
      long mins=sec/60; long hours=mins/60; mins%=60; sec%=60;
      long amount=Math.round((sec + mins*60 + hours*3600) * (rates[i]/3600.0));
      info.get(i).setText(String.format(Locale.US,"%02d:%02d:%02d  •  %s تومان",hours,mins,sec,fmt(amount)));
    }
    Runnable tick=new Runnable(){public void run(){for(int i=0;i<7;i++)if(running[i])update(i);h.postDelayed(this,1000);}};
    String fmt(long x){return String.format(Locale.US,"%,d",x).replace(',','٬');}
}